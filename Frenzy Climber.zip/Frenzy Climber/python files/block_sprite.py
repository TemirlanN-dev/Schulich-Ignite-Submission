import pygame, os

class Stone(pygame.sprite.Sprite):
    

    def __init__(self, size, position):
        super().__init__()
        image_location = os.path.join("assets", "platform_tile.png")
        self.image = pygame.image.load(image_location).convert_alpha()
        self.image = pygame.transform.scale(self.image, (size, size))
        self.rect = self.image.get_rect(topleft = position) # Places the image whereever the position will be
        
      # to make the blocks go down
    def update(self, y_down):
        self.rect.y += y_down