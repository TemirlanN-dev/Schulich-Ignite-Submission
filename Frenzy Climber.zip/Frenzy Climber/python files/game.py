import pygame
import sys
 
from setting import *
from block_sprite import Stone
from structure import Structure
from player import Player

# Setup
pygame.init()
frame_rate = 60
       
# Colours
BLACK = (0,0,0)
DARK_GREEN = (0, 153, 51)

# Creating the screen
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
screen.set_alpha(0)

# Game Structure
layout = Structure(map, screen)                    

while True: 
    # To close the game
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
     
    
    # Makes Background
    screen.fill(BLACK)

    # Draws
    layout.draw()

    # Makes sure everything is on screen
    clock.tick(frame_rate)
    pygame.display.update()
    pygame.display.flip()

    
