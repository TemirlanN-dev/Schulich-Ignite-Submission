from calendar import c 
from numpy import c_
import pygame, sys
from block_sprite import Stone
from setting import *
from player import Player
from coin import Coin

class Structure:
    #                   map   screen
    def __init__(self, data, surface):
        super().__init__()
        self.surface = surface
        self.place_layout(data) # passes in data as a paremeter
    
    def place_layout(self, layout): # finding positions of the letters in map to place stones
        self.stones = pygame.sprite.Group()
        self.player = pygame.sprite.GroupSingle()
        self.coin = pygame.sprite.GroupSingle()

        for r_index, r in enumerate(layout):

            for c_index, c in enumerate(r):

                x = c_index*stone_size # gets the position and makes sure the blocks don't overlap
                y = r_index*stone_size

                if c == "x":
                    stone = Stone(stone_size, (x,y))
                    self.stones.add(stone)

                elif c == 'i':
                    player1 = Player((x, y))
                    self.player.add(player1)
                elif c == "c":
                    coin = Coin((x,y))
                    self.coin.add(coin)

    def v_collision(self):
        player = self.player.sprite

        for sprite in self.stones.sprites(): # same logic as H_collision
            if sprite.rect.colliderect(player.rect):
                if player.direction.y > 0:
                    player.rect.bottom = sprite.rect.top
                    player.direction.y = 0# so gravity becomes non-existant
                elif player.direction.y < 0:
                    player.rect.top = sprite.rect.bottom
                    player.direction.y += 1 # so you dont stick to the top
    
    
    def coin_collision(self):
        player = self.player.sprite

        for sprite in self.coin.sprites(): # same logic as H_collision
            if sprite.rect.colliderect(player.rect):
                print("You won, congrats...however, the game you beat was only practice...see you in 20 years...")
                pygame.quit()
                sys.exit()

    def flip_image(self):
        player = self.player.sprite

        if player.direction.x < 0:
            player.image = pygame.transform.flip(player.image, True, False)
        elif player.direction.x > 0:
            player.image = pygame.transform.flip(player.image, True, False)

    def draw(self):

        self.stones.update(0) # can shift the blocks
        self.stones.draw(self.surface)

        self.player.update()
        self.v_collision()
        self.flip_image()
        self.player.draw(self.surface)

        self.coin_collision()
        self.coin.draw(self.surface)

        
