from turtle import position
import pygame, os, sys
import math
from setting import *

class Player(pygame.sprite.Sprite):

    def __init__(self, position):
        super().__init__()
        image_location = os.path.join("assets", "player.png")
        self.image = pygame.image.load(image_location).convert_alpha()
        self.image = pygame.transform.scale(self.image, (25, 30))
        self.rect = self.image.get_rect(topleft = position)
        self.direction = pygame.math.Vector2(0,0)
        self.speed = 3
        self.gravity = 0.8
        self.jump_speed = -15
        self.is_jumping = False
        self.h_movement = 0

    def move(self):
        key = pygame.key.get_pressed()

        if key[pygame.K_RIGHT] and self.rect.x < screen_width - 20:
            self.direction.x = 1

        elif key[pygame.K_LEFT] and self.rect.x > 0:
            self.direction.x = -1
            
        else:
            self.direction.x = 0
  
        if key[pygame.K_SPACE] and not self.is_jumping:
            self.jumping()  
            self.is_jumping = True
        
        elif self.direction.y == 0:
            self.is_jumping = False
        
        if self.rect.y > screen_height:
            print("You lost, jeez...however, the game you lost was only practice...see you in 20 years...")
            pygame.quit()
            sys.exit()
        
        if self.rect.y < 0:
            self.direction.y = 0
        
    def place_gravity(self):
        self.direction.y += self.gravity
        

    def jumping(self):
        self.direction.y = self.jump_speed
        
    def update(self):
        self.move()
        self.place_gravity()
        self.rect.x += self.direction.x * self.speed
        self.rect.y += self.direction.y
        
