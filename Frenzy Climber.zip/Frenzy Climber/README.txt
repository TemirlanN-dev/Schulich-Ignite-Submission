Simple Rules:
    LEFT is left arrow
    RIGHT is right arrow
    JUMP is spacebar
    
    If you fall off map you LOSE
    If you get the coin at the top you WIN

    You play as an assassin who can climb and jump (including jumping mid-air)

    run game.py to play